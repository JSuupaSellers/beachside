<script>

</script>

<div class="flex items-center gap-4">
    <button class="specialBtn">
        <p class="text-base sm:text-lg md:text-xl">Find Us</p>
    </button>
    <button class="specialBtnDark">
        <p class="text-base sm:text-lg md:text-xl">Learn How</p>
    </button>
</div>